const sendBtn = document
  .getElementById("sendBtn")
  .addEventListener("click", () => {});

function sendEmail() {}
